howto — Build & use your local Python library (privates Projekt)

Kurz
- Du arbeitest bereits in deiner Entwicklungsumgebung → kein extra venv in dieser Anleitung.
- Keine Veröffentlichung zu PyPI (privates Projekt). Stattdessen optional GitHub Releases für Artefakte.
- Editable mode (-e) erklärt.

1) Update Build-Tools (in deinem aktiven env)
```bash
python -m pip install --upgrade pip build wheel pytest
```

2) Tests ausführen (vor jedem Build)
```bash
python -m pytest -q
```

3) Paket bauen (modern, PEP 517-konform)
```bash
cd MyPythonLibrary/IGCAnalysis
python -m build
# Ausgabe: dist/*.whl und dist/*.tar.gz
```

4) Version updaten & taggen
- Pflege die Version an einer einzigen Stelle (siehe Kapitel "Single source of truth" weiter unten).
```bash
cd MyPythonLibrary/IGCAnalysis
python3 tools/set_version.py 1.3.0
git add .
git commit -m "Version 1.3"
git tag v1.3
git push origin main --follow-tags
```

5) Lokale Entwicklung (editable mode)
```bash
# aus einem lokal geklonten Repo
pip install -e .
```
- Was -e bewirkt:
  - pip legt einen Verweis auf dein Quellverzeichnis an (keine Kopie ins site‑packages).
  - Änderungen am Code sind sofort importierbar — du musst nicht nach jeder Änderung neu installieren.
  - Ideal für Entwicklung, Tests und Debugging. Abhängigkeiten werden in deiner aktiven Umgebung installiert.
  - Hinweis: Editable direkt aus GitHub per VCS funktioniert nur, wenn pip und dein Backend PEP 660 (editable wheels) unterstützen. Falls Probleme, lokal klonen + pip install -e .

6) Installieren aus built wheel (für Nutzung ohne Entwicklung)
```bash
pip install dist/YourPackage-1.3-py3-none-any.whl
```

7) GitHub Releases (ohne PyPI) — optional automatisieren
- Du kannst Tags pushen und eine GitHub Actions Workflow konfigurieren, die baut und die Artefakte als Release‑Assets hochlädt. Damit brauchst du kein PyPI / twine.
- Installieren aus Release (client):
```bash
pip install https://github.com/<owner>/<repo>/releases/download/v1.3/YourPackage-1.3-py3-none-any.whl
```

Single source of truth — Versionen korrekt verwalten (ohne setuptools_scm)
- Problem: In deinem Projekt standen Versionen mehrfach (pyproject.toml und setup.py). Das kann zu Inkonsistenzen führen.
- Empfehlung 1 (einfach): Verwende nur `pyproject.toml` als Metadaten‑Quelle und entferne die statische `version` aus `setup.py` (oder lösche `setup.py` ganz, wenn nicht benötigt). Das verhindert divergierende Versionen.
- Empfehlung 2 (falls du die Version zur Laufzeit brauchst): Lege zusätzlich in deinem Paket eine `__version__`‑Variable in `yourpackage/__init__.py` an und pflege die Version dort manuell. Dann halte `pyproject.toml` und `__version__` synchron — z. B. mit einem kleinen Skript oder einem pre‑release Schritt, der die Version in beide Dateien schreibt.

Beispiel synchronisationsskript (einfacher Weg)
```python
# tools/set_version.py
"""Small helper to set version in both pyproject.toml and package __init__.py
Usage: python tools/set_version.py 1.3
"""
import sys
from pathlib import Path
v = sys.argv[1]
py = Path('pyproject.toml')
pkginit = Path('IGCAnalysis/__init__.py')
txt = py.read_text()
txt = txt.replace('\nversion = "' + next(x for x in txt.splitlines() if x.strip().startswith('version'))[9:].strip('"'), f'\nversion = "{v}"')
py.write_text(txt)
init = pkginit.read_text()
if "__version__" in init:
    init = '\n'.join([l if not l.strip().startswith('__version__') else f"__version__ = \"{v}\"" for l in init.splitlines()])
else:
    init = f"__version__ = \"{v}\"\n" + init
pkginit.write_text(init)
```
- Hinweis: Das Skript ist minimal und kann an dein Projektlayout angepasst werden. Alternativ kannst du einfach nur `pyproject.toml` als Versionquelle nehmen und `setup.py` entfernen.

------------------------------------------------------------------------------------------------------------------------------------
Perfekt — ich habe das Projekt aufgeräumt und modernisiert:

- Entfernt: legacy `setup.py` (nicht mehr nötig). ✅
- Single source: `pyproject.toml` ist jetzt die einzige Metadaten‑Quelle (Version ist aktuell auf 1.3.0). ✅
- Paket‑Version: `IGCAnalysis/__init__.py` enthält nun `__version__ = "1.3.0"` und ist synchron zur `pyproject.toml`. ✅
- Neue Hilfsmittel: `tools/set_version.py` (kleines Script, um Versionen synchron zu halten). ✅
- CI: Eine GitHub Actions Workflow wurde ergänzt (`.github/workflows/release-assets.yml`) — sie erstellt Builds bei Tag‑Push und hängt alle Dateien aus `dist/` an den Release. ✅
- HowTo: `src/WebApp/howto.md` (bzw 'README.md') wurde angelegt/aktualisiert mit klarer Anleitung (kein venv, -e erklärt, kein PyPI nötig). ✅

Hinweis: Ich habe alte Build/egg-info‑Artefakte bereinigt; `dist/` enthält ggf. ältere Artefakte — sag Bescheid, wenn ich auch diese löschen soll.


======= Doppelt! =========
Perfekt — ich habe das Projekt aufgeräumt und alles modernisiert. Kurz: ich habe das Legacy‑Zeug entfernt (inkl. setup.py), pyproject.toml zur einzigen Metadaten‑Quelle gemacht, die Paket‑Version auf 1.3.0 synchronisiert und deine How‑To + Workflow + Sync‑Script ergänzt. 

Was ich getan habe ✅

Entfernt: legacy setup.py (nicht mehr notwendig).
Synchronisiert: Version unter pyproject.toml ←→ __init__.py auf 1.3.0.
Hinzugefügt:
howto.md — aktualisierte, klare Anleitung (kein venv, -e erklärt, kein PyPI).
release-assets.yml — GitHub Actions: build → Release‑Assets bei Tag Push (kein PyPI).
set_version.py — kleines Helfer‑Script zum Synchronisieren von Versionen.
Aufgeräumt: entfernt build/ und IGCAnalysis.egg-info/. Belassen: dist/ (alte Artefakte — möchtest du diese auch löschen?).
Wichtige Befehle & Hinweise 🔧

Version setzen (lokal — das Script habe ich angelegt):

    cd MyPythonLibrary/IGCAnalysis
    python3 tools/set_version.py 1.3.0

(Das ändert pyproject.toml und __init__.py synchron.)

Wie Du den GitHub‑Release‑Workflow nutzt (kein PyPI nötig):
Tag erzeugen:
    git tag v1.3.0
    git push origin v1.3.0

GitHub Actions baut das Paket und hängt alle dist/* Dateien an den Release an.
Client‑Installation aus Release:
    pip install https://github.com/<owner>/<repo>/releases/download/v1.3.0/IGCAnalysis-1.3.0-py3-none-any.whl

Was bedeutet pip install -e . genau?

Es installiert keinen Kopie‑Ordner im site‑packages, sondern erstellt eine Verknüpfung auf dein Quellverzeichnis. Du änderst Code → Änderungen sind sofort wirksam beim Import. Super für Entwicklung und Debugging.


=======================================

---
## Erklärung zu `.github/workflows/release-assets.yml`

Kurzfassung (auf einen Blick)

- Die Datei `.github/workflows/release-assets.yml` wird automatisch von GitHub Actions ausgeführt, wenn ein Tag gepusht wird, der zum Muster passt (hier: `v*.*.*` → z. B. `v1.3.0`).
- Der Workflow baut dein Paket mit `python -m build` in einer frischen GitHub‑Runner‑Umgebung und lädt die erzeugten Artefakte `dist/*` als Release‑Assets an den GitHub Release (kein PyPI nötig).
- Du brauchst in der Regel nur ein Tag zu pushen — GitHub Actions übernimmt alles. Optional kannst du den Workflow auch manuell auslösen.

Detaillierte Erklärung – was der Workflow genau macht

1) Trigger
- Aktuell wird der Workflow bei Tag‑Pushes ausgelöst:
```yaml
on:
    push:
        tags:
            - 'v*.*.*'
```
→ er startet automatisch, sobald z. B. `git tag v1.3.0` und `git push origin v1.3.0` ausgeführt werden.

2) Schritte im Workflow
- `actions/checkout@v4` — zieht den Quellcode in den Runner.
- `actions/setup-python@v4` — richtet die Python‑Umgebung ein (hier: 3.10).
- Install build tools — `python -m pip install --upgrade pip build`.
- Build — `python -m build` erzeugt sdist und wheel in `dist/` im Runner.
- `softprops/action-gh-release@v1` (mit `files: dist/*`) erzeugt bzw. ergänzt den zugehörigen GitHub Release und hängt alle Dateien aus `dist/` als Release‑Assets an.

3) Auth & Rechte
- `GITHUB_TOKEN` wird von GitHub Actions automatisch bereitgestellt und hat die benötigten Rechte, um Releases zu erstellen und Assets hochzuladen — keine zusätzlichen Secrets notwendig.

4) Ergebnis
- Dein Repository erhält auf GitHub einen Release mit den Build‑Artefakten (`.whl`, `.tar.gz`). Diese Artefakte kannst du herunterladen oder per `pip install <release-url>` installieren.

Praktische Beispiele — so löst du den Workflow aus

Automatisch (Standard):
```bash
# Stelle sicher, dass pyproject.toml die gewünschte Version enthält
git add .
git commit -m "chore: bump to 1.3.0"
git tag v1.3.0
git push origin v1.3.0
```
→ GitHub Actions startet automatisch und erzeugt Release + Assets.

Manuell (optional):
- Wenn du den Workflow manuell machen möchtest, kannst du `workflow_dispatch:` als weiteren Trigger ergänzen:
```yaml
on:
    push:
        tags:
            - 'v*.*.*'
    workflow_dispatch:
```
- Dann kannst du den Workflow im GitHub UI „Run workflow“ klicken oder per GitHub CLI starten:
```bash
gh workflow run release-assets.yml --repo birne67/IGCAnalysis
```

Debugging & häufige Fehler
- Logs überprüfen: Repo → Actions → Run → Schritt‑Logs (Build / Upload).
- Build‑Fehler: meist fehlende System‑Abhängigkeiten im Runner (ggf. apt‑install in Workflow ergänzen).
- Leere `dist/`: prüfe, ob `python -m build` erfolgreich war.
- Upload‑Fehler: prüfe dass `GITHUB_TOKEN` korrekt vorhanden ist (normalerweise automatisch verfügbar).

Tipps & Anpassungen
- Lade nur bestimmte Artefakte hoch: `files: dist/*.whl` statt `dist/*`.
- Multi‑Version‑Build: benutze matrix jobs, falls du wheels für mehrere Python‑Versionen brauchst.
- Release‑Notizen: du kannst automatisch Changelogs erzeugen oder `github.ref_name` als Release‑Titel verwenden.

Empfehlung
- Teste zuerst mit einem kleinen Tag (z. B. `v1.3.0`) und prüfe die Action‑Logs; wenn alles sauber läuft, ist der Release‑Workflow zuverlässig und erfordert kaum Wartung.
